// CMSC 451 7380 Design and Analysis of Computer Algorithms
// Week 4 - Project 1
// Husain Rizvi
// November 11, 2022

// This program essentially benchmarks the behavior of Java implementations of a 
// bubble sort sorting algorithm. It includes both an iterative and recursive version
// of the algorithm and produces a report based on randomly generated data sets. 

package Project1;   // Project1 package 

// This IncorrectSortError class contains the code to create
// the IncorrectSortError exception for the methods to throw
// and add an error message to 

// Creating public class IncorrectSortError that extends the Exception class

public class IncorrectSortError extends Exception {	// Start of IncorrectSortError class

	// Creating a constructor with no arguments

	public IncorrectSortError() {}

	// Creating a constructor with a String as an argument

	public IncorrectSortError(String errorMessage) {	// Start of IncorrectSortError constructor with arguments

		// Using super() on the message to construct a new exception
        // with the specified detail message that can be retrieved
        // later by the getMessage() method

		super(errorMessage);

	}	// End of IncorrectSortError constructor with arguments

}	// End of IncorrectSortError class 
