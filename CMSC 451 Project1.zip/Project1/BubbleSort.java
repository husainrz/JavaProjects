// CMSC 451 7380 Design and Analysis of Computer Algorithms
// Week 4 - Project 1
// Husain Rizvi
// November 11, 2022

// This program essentially benchmarks the behavior of Java implementations of a 
// bubble sort sorting algorithm. It includes both an iterative and recursive version
// of the algorithm and produces a report based on randomly generated data sets. 

package Project1;   // Project1 package 

// This BubbleSort class implements the SortArray interfaces which means
// it also inherits the SortArray interfaces methods such as 
// getCount(), getTime(), iterativeSort(), and recursiveSort(). While
// inheriting the SortArray interfaces methods it creates the bodies for the 
// methods so that the Benchmark class can instantiate a BubbleSort class object
// and call the inherited methods to complete the iterative and recursive sorts 

// Creating public class BubbleSort that implements the SortArray interface 

public class BubbleSort implements SortArray{   // Start of BubbleSort() class 

    // Creating private static variables to make them more easily accessible
    // from inside the BubbleSort class 

	private static int count = 0;   // Creating private static integer variable count and initializing it 
    private static long start, end = 0; // Creating private static long variables start and end and initializing them 
    
    // Bubble sort sorting algorithms swap the adjacent elements if they are in the wrong order
    // to avoid an incorrect sort. Therefore, we are creating a public void method, swap(), that 
    // takes two integers and an integer array as arguments. This method does as it's name says,
    // it swaps elemenst in the given array if they are in the wrong order  

    public void swap(int[] array, int i, int a){  // Start of swap() method 

    	count++;    // Incrementing count value by 1

         // Assigning the value of the i index value of the integer array to the new integer variable, num

    	int num = array[i];

        // Assigning the value of the b index value of the integer array to the i index value of the integer array

    	array[i] = array[a];

        // Assigning the num integer to the value of the a index of the integer array 

    	array[a] = num;
    
    }   // End of swap() method 

    // Creating inherited interativeSort() method that is inherited from the SortArray interface
    // This method returns an integer array, takes an integer array as an argument, and throws
    // an IncorrectSortError exception. 
    // This method performs the calculations and operations for the iterative sort sorting algorithm 
    // approach to the Bubble Sort sorting algorithm 
    
    public int[] iterativeSort(int[] array) throws IncorrectSortError{  // Start of inherited iterativeSort() method 
    	
        // Calling System class nanoTime() method that returns the current value of the running JVM's 
        // high resolution time source in nanoseconds and returns that value to the start long variable 

        start = System.nanoTime();

    	int n = array.length; // Getting the length of the integer array, array, and assigning the value to the integer, n

        // Creating a for loop to run through the array to check if elements need to be swapped in order to be sorted
        // and if they do need to be swapped the for loop calls the swap() method to get the elements of the
        // integer array, array, swapped  

    	for (int i = 0; i < n - 1; i++){    // Start of for loop 

            // Creating a for loop to run through the length of the integer array to check 
            // if elements need to be swapped. If they do need to be swapped, the swap() method
            // is called to swap the elements in the given integer array 

    		for (int a = 0; a < n - 1 - i; a++){    // Start of nested for loop
                
    			count++;    // Incrementing count value by 1

                // Creating an if statement to check if the elements in the integer array
                // need to be swapped 

    			if (array[a] > array[a + 1]){ // Start of if statement  

                    // Calling swap() method and using the integer array and the two current values
                    // (a, a + 1) as the arguments for the method call 

                    swap(array, a, a + 1);

                }   // End of if statement 

    		}   // End of nested for loop 

    	}   // End of for loop 

        // Calling System class nanoTime() method that returns the current value of the running JVM's 
        // high resolution time source in nanoseconds and returns that value to the end long variable 
    	
    	end = System.nanoTime();

        return array;   // Returning given integer array 

    }   // End of inherited iterativeSort() method  
    
    // Creating inherited recursiveSort() method that is inherited from the SortArray interface
    // This method doesn't return anything but takes an integer array and an integer as arguments.
    // This method performs the calculations and operations for the recursive sort sorting algorithm 
    // approach for the Bubble Sort sorting algorithm  
    
    private void recursiveSort(int[] array, int n){ // Start of recursiveSort() method 

        // Creating a for loop to run through the length of the integer array to check 
        // if elements need to be swapped. If they do need to be swapped, the swap() method
        // is called to swap the elements in the given integer array 
    	
    	for (int i = 0; i < n - 1; i++){    // Start of for loop 

    		count++;    // Incrementing count value by 1

            // Creating an if statement to check if the elements in the integer array
            // need to be swapped 

    		if(array[i] > array[i+1]){  // Start of if statement 

                // Calling swap() method and using the integer array and the two current values
                // (i, i + 1) as the arguments for the method call 

    			swap(array, i, i+1);

    		}   // End of if statement 

    	}   // End of for loop 

        // Creating an if statement to check if it is needed to call the recursiveSort() recursive method  
    	
    	if(n - 1 > 1){  // Start of if statement
            
            // Calling recursiveSort() recursive method with the integer array and n -1 as the arguments 
            
    		recursiveSort(array, n - 1);     

    	}   // End of if statement 

    }   // End of recursiveSort() method 

    // Creating inherited recursiveSort() method that is inherited from the SortArray interface
    // This method doesn't return anything but takes an integer array and an integer as arguments and
    // throws an IncorrectSortError excpetion. 
    // This method performs the calculations and operations for the recursive sort sorting algorithm 
    // approach for the Bubble Sort sorting algorithm  
    
    public int[] recursiveSort(int[] array) throws IncorrectSortError{  // Start of inherited recursiveSort() method 

        // Calling System class nanoTime() method that returns the current value of the running JVM's 
        // high resolution time source in nanoseconds and returns that value to the start long variable 

    	start = System.nanoTime();
    	
    	int n = array.length;    // Getting the length of the integer array, array, and assigning the value to the integer, n

    	recursiveSort(array, n);    // Calling recursiveSort() recursive method with the integer array and n -1 as the arguments

        // Calling System class nanoTime() method that returns the current value of the running JVM's 
        // high resolution time source in nanoseconds and returns that value to the end long variable 

    	end = System.nanoTime();

    	return array;   // Returning given integer array 

    }   // End of inherited recursiveSort() method 

    // Creating public int inherited getCount() method that returns the integer count value  
    
    public int getCount(){  // Start of getCount() inherited method 

        int result = count; // Assigning count variable value to integer variable, result 

        count = 0;  // Assigning count variable value to 0 

        return result;  // Returning integer variable, result 

    }   // End of getCount() method 

    // Creating public long inherited getTime() method that returns the long time value  

    public long getTime(){  // Start of inherited getTime() method

        // Subtracting the end time from the start time to get
        // the time value of how long it took to complete the sorting
        // algorithm performed and assigning the value to the long variable, time   

        long time = end - start;

        // Resetting the end and start variable values to 0 

        end = 0;    // Resetting end variable value to 0 
        start = 0;  // Resetting start variable vlaue to 0 

        return time;    // Returning long variable, time 
        
    }   // End of inherited getTime() method 

}   // End of BubbleSort class 