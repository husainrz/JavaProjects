// CMSC 451 7380 Design and Analysis of Computer Algorithms
// Week 4 - Project 1
// Husain Rizvi
// November 11, 2022

// This program essentially benchmarks the behavior of Java implementations of a 
// bubble sort sorting algorithm. It includes both an iterative and recursive version
// of the algorithm and produces a report based on randomly generated data sets. 

package Project1;   // Project1 package 

import java.util.*;     // Importing java.util package with all of its contents
import java.util.stream.IntStream;  // Importing java.util.stream.IntStream package 
import javax.swing.*;   // Importing javax.swing package with all of its contents 

// This Benchmark class essentially performs the benchmarking of the behavior of Java 
// implementations of a bubble sort sorting algorithnm and creates the methods 
// that are called in the Report class to generate the reports for both the results
// from the iterative algorithm and the recursive algorithm   

// Creating public class Benchmark 

public class Benchmark{ // Start of Benchmark class 

    // Creating private static variables to make them more easily accessible
    // from inside the Benchmark class 

    private static JFrame mainFrame = new JFrame(); // JFrame private static variable, mainFrame
    private static JTable mainTable = new JTable(); // JTable private static variable, mainTable 
    private int[] intArray; // Creating an integer array private static variable, intArray
    // Initializing private double variables itAvgCount, itAvgTime, reAvgCount, reAvgTime, itCoefCount, itCoefTime,
    // reCoefCount, reCoefTime, and assigning them the value of 0  
    private double itAvgCount, itAvgTime, reAvgCount, reAvgTime, itCoefCount, itCoefTime, 
    reCoefCount, reCoefTime = 0;

    // Creating private static arrays to make them more easily accessible 
    // from inside the Benchmark class and assigning them all the size of 50 elements
    // to represent the number of runs (50)

    private int[] itCount = new int[50]; // Private int array, itCount 
    private int[] reCount = new int[50]; // Private int array, reCount
    private long[] itTime = new long[50];  // Private long array, itTime
    private long[] reTime = new long[50];   // Private long array, reTime

    // Creating public constructor Benchmark() that takes an integer array as the argument 
    // and creates new benchmarks based on the size of the array given as the argument to the constructor call 
    
    public Benchmark(int[] sizes){  // Start of Benchmark() class constructor w/ an int array as the parameter 

        // Using the IntStream class range() method to return a sequential ordered IntStream from the first index (0) to 
        // the length of the given integer array and assigns the returned values to the newly created IntStream object, result  

        IntStream result = IntStream.range(0, sizes.length);

        // Calling the forEach() method on the IntStream object, result, to create a new benchmark for each element of the IntStream (result)
        // based on the size of the array given as the argument to the constructor call 

        result.forEach(i -> new Benchmark(sizes[i]));
    
    }   // End of Benchmark() class constructor w/ an int array as the parameter 

    // Creating a private constructor Benchmark() that takes an integer as the argument and 
    // creates/generates a random number for each element in the IntStream stream 
    // and adds the number to the intArray integer array with a bound of 1000

    private Benchmark(int n){  // Start of Benchmark() class constructor w/ an integer as the parameter 

        // Using the IntStream class range() method to return a sequential ordered IntStream from the first index (0) to 
        // the number of runs (50) and assigns the returned values to the newly created IntStream object, result 

        IntStream result = IntStream.range(0, 50);

        // Calling the forEach() method on the IntStream object, result, to create/generate a random number
        // for each element in the IntStream stream by using the Random class and then adding the 
        // generated number to the intArray integer array with a bound of 1000

        result.forEach(i -> {   // Start of forEach() method call 

            // Initializing the integer array, intArray, by using the given integer argument in the Benchmark() constructor
            // method call as the size of the intArray  

            intArray = new int[n];

            // Using the IntStream class range() method to return a sequential ordered IntStream from the first index (0) to 
            // the size of the array (n) and assigns the returned values to the newly created IntStream object, result1 

            IntStream result1 = IntStream.range(0, n);

            // Calling the forEach() method on the IntStream object, result1, to create/generate a random number
            // for each element in the IntStream stream by using the Random class and then adding the 
            // generated number to the intArray integer array with a bound of 1000

            result1.forEach(a -> {  // Start of nested forEach() method call 

                // Initializing a Random class object, random, to generate a random number 

                Random random = new Random();

                // Calling nextInt() method on the Random class object, random, and setting the bound to 1000 
                // to generate a random number that does not exceed 1000 and assigning that random number 
                // to the integer array, intArray

                intArray[a] = random.nextInt(1000);
            
            }); // End of nested forEach() method call 

            // Creating a try catch block around the runSorts() method call to handle the 
            // IncorrectSortError exception should an error produce where there was an
            // incorrect sort

            try {   // Start of try catch block 
                sort();     // Calling the runSorts() method to run the iterative and recursive sorts 
            } catch (IncorrectSortError e) {    // Start of catch block 
                System.out.println(e.getMessage()); // Printing out the IncorrectSortError message by calling the getMessage() method on the exception 
            }   // End of try catch block 

        }); // End of forEach() method call 

        displayReport(n);   // Calling the displayReport() method with the array size, n, as the argument 
    
    }   // End of Benchmark() class constructor w/ an integer as the parameter

    // Creating a private method, sort(), that doesn't return anything and throws an IncorrectSortError exception
    // This method runs both 

    private void sort() throws IncorrectSortError { // Start of sort() method 

        // Creating local int and long variables, iCount, rCount, iIndex, rIndex, iTime, and rTime
        // to represent the different values of the data sets (iterative sort count, recursive sort count, 
        // iterative sort index, recursive sort index, iterative sort time, recursive sort time) and
        // initializing them all and assigning them the value 0  

        int iCount = 0;    // Local int variable iCount
        int rCount = 0;     // Local int variable rCount
        int iIndex = 0;     // Local int variable iIndex
        int rIndex = 0;     // Local int variable rIndex
        long iTime = 0;     // Local long variable iTime
        long rTime = 0;     // Local long variable rTime 

        // Creating and declaring BubbleSort class object bubbleSort in order
        // to run the necessary methods (iterativeSort, recursiveSort, getCount, getTime)
        // for the sorting algorithms 

        BubbleSort bubbleSort = new BubbleSort();  

        // Calling BubbleSort class method iterativeSort() on the BubbleSort class object, 
        // bubbleSort, and using the integer array that contains the random numbers as the argument 
        // for the method call and assigning the returning integer array to the new sortedArray1 array  

        int[] sortedArray1 = bubbleSort.iterativeSort(intArray);

        // Calling BubbleSort class method getCount() on the BubbleSort class object, 
        // bubbleSort, and assigning the returning integer to the new count variable 

        int count = bubbleSort.getCount();

        // Calling BubbleSort class method getTime() on the BubbleSort class object, 
        // bubbleSort, and assigning the returning integer to the new time variable 

        long time = bubbleSort.getTime();

        // Assigning the resulting count value from the getCount() method call to the iterative sort count variable, iCount
        // and assigning the resulting time value from the getTime() method call to the iterative sort time variable, iTime

        iCount = count; // Assigning count value to iCount 
        iTime = time;   // Assigning time value to iTime 

        // Assigning the iterative sort count variable, iCount, to the itCount integer array at the specified 
        // index value, iIndex. Assigning the iterative sort time variable, iTime, to the itTime long array 
        // at the specified index value, iIndex.

        itCount[iIndex] = iCount;   // Assigning iCount to itCount integer array at iIndex index value 
        itTime[iIndex] = iTime; // Assigning iTime to itTime long array at iIndex index value 

        iIndex++;   // Increasing iIndex index value by 1 

        // Calling BubbleSort class method recursiveSort() on the BubbleSort class object, 
        // bubbleSort, and using the integer array that contains the random numbers as the argument 
        // for the method call and assigning the returning integer array to the new sortedArray2 array  

        int[] sortedArray2 = bubbleSort.recursiveSort(intArray);

        // Calling BubbleSort class method getCount() on the BubbleSort class object, 
        // bubbleSort, and assigning the returning integer to the new count variable 

        count = bubbleSort.getCount();

        // Calling BubbleSort class method getTime() on the BubbleSort class object, 
        // bubbleSort, and assigning the returning integer to the new time variable 

        time = bubbleSort.getTime();

        // Assigning the resulting count value from the getCount() method call to the recursive sort count variable, rCount
        // and assigning the resulting time value from the getTime() method call to the recursive sort time variable, rTime

        rCount = count; // Assigning count value to rCount 
        rTime = time;   // Assigning time value to rTime 

        // Assigning the recursive sort count variable, rCount, to the reCount integer array at the specified 
        // index value, rIndex. Assigning the recursive sort time variable, rTime, to the reTime long array 
        // at the specified index value, rIndex.
        
        reCount[rIndex] = rCount;   // Assigning rCount to reCount integer array at rIndex index value 
        reTime[rIndex] = rTime;     // Assigning rTime to reTime long array at rIndex index value 

        rIndex++;   // Increasing rIndex index value by 1 

    }   // End of sort() method 

    // Creating private void method displayReport() that takes an integer as an argument 
    // This method performs the calculations for each run and data value (average count, time, SD, etc.) 
    // by using for loops and the prints out a data set table with the averages and outputs a JTable table
    // with the values   

    private void displayReport(int arraySize) { // Start of displayReport() method 

        // Creating a for loop to run through each run out of the 50 runs
        // and calculate the average iterative sort count, recursive sort count,
        // iterative sort time, and recursive sort time for each run and 
        // assigns the values to the appropriate variables 

        for (int i = 0; i < 50; i++) {  // Start of for loop 

            // Assigning the current value (i) of the itCount integer array 
            // to the itAvgCount double variable 

            itAvgCount += itCount[i];

            // Assigning the current value (i) of the itTime long array 
            // to the itAvgTime double variable 

            itAvgTime += itTime[i];

            // Assigning the current value (i) of the reCount integer array 
            // to the reAvgCount double variable 

            reAvgCount += reCount[i];

            // Assigning the current value (i) of the reTime integer array 
            // to the reAvgCount double variable 

            reAvgTime += reTime[i];

        }   //  End of for loop 

        // Dividing the following values (itAvgCount, itAvgTime, reAvgCount, reAvgTime) by the arraySize integer value and 
        // assigning the returning value to the values listed above 

        itAvgCount /= arraySize;    // Diving itAvgCount by arraySize and assigning the returning value to itAvgCount
        itAvgTime /= arraySize;     // Diving itAvgTime by arraySize and assigning the returning value to itAvgTime
        reAvgCount /= arraySize;    // Diving reAvgCount by arraySize and assigning the returning value to reAvgCount
        reAvgTime /= arraySize;     // Diving reAvgTime by arraySize and assigning the returning value to reAvgTime

        // Creating a for loop to run through each run out of the 50 runs
        // and calculates the coefficient iterative sort count, recursive sort count,
        // iterative sort time, and recursive sort time for each run by calling the Math class pow() method
        // and assigns the values to the appropriate variables 

        for (int i = 0; i < 50; i++) { // Start of for loop 

            // Calling the Math class pow() method and finding the value of the 
            // iterative average count double variable, itAvgCount, subtracted by the current value
            // of the iterative count integer array, itCount, squared and adding the squared value to the 
            // itCoefCount double variable and assigning it back to the itCoefCount variable 
            
            itCoefCount += Math.pow(itAvgCount - itCount[i], 2);

            // Calling the Math class pow() method and finding the value of the 
            // iterative average time double variable, itAvgCount, subtracted by the current value
            // of the iterative time long array, itTime, squared and adding the squared value to the 
            // itCoefTime double variable and assigning it back to the itCoefTime variable 

            itCoefTime += Math.pow(itAvgTime - itTime[i], 2);

            // Calling the Math class pow() method and finding the value of the 
            // recursive average count double variable, reAvgCount, subtracted by the current value
            // of the recursive count integer array, reCount, squared and adding the squared value to the 
            // reCoefCount double variable and assigning it back to the reCoefCount variable 

            reCoefCount += Math.pow(reAvgCount - reCount[i], 2);

            // Calling the Math class pow() method and finding the value of the 
            // recursive average time double variable, reAvgTime, subtracted by the current value
            // of the recursive time long array, reTime, squared and adding the squared value to the 
            // reCoefTime double variable and assigning it back to the reCoefTime variable 

            reCoefTime += Math.pow(reAvgTime - reTime[i], 2);
        
        }   // End of for loop 

        itCoefCount /= arraySize;  // Diving itCoefCount by arraySize and assigning the returning value to itCoefCount
        // Calling the Math class sqrt() method on the itCoefCount double variable to find the square root and assigning
        // the value back to itCoefCount
        itCoefCount = Math.sqrt(itCoefCount);

        itCoefTime /= arraySize;    // Diving itCoefTime by arraySize and assigning the returning value to itCoefTime
        // Calling the Math class sqrt() method on the itCoefTime double variable to find the square root and assigning
        // the value back to itCoefTime
        itCoefTime = Math.sqrt(itCoefTime);

        reCoefCount /= arraySize;  // Diving reCoefCount by arraySize and assigning the returning value to reCoefCount
        // Calling the Math class sqrt() method on the reCoefCount double variable to find the square root and assigning
        // the value back to reCoefCount
        reCoefCount = Math.sqrt(reCoefCount);

        reCoefTime /= arraySize;    // Diving reCoefTime by arraySize and assigning the returning value to reCoefTime
        // Calling the Math class sqrt() method on the reCoefTime double variable to find the square root and assigning
        // the value back to reCoefTime
        reCoefTime = Math.sqrt(reCoefTime);

        // Creating Object array named column that contains an array of strings for columns 

        Object[] column = {"Size", "Avg Count", "Coef Count", "Avg Time", "Coef Time"}; 

        // Creating Object array named data that contains an array of the data for each column 
        // and calling the Math class round() method on the average iterative sort and recursive 
        // sort values and using the returning calulated values as elements in the array 

        Object[][] data = {{arraySize, Math.round(itAvgCount), Math.round(itCoefCount), 
            Math.round(itAvgTime), Math.round(itCoefTime)}};

        // Initializing a new JTable object, mainTable, and using the data and column arrays as the arguments
        // to the method call 

        mainTable = new JTable(data, column);

        // Calling the add() method to add the mainTable JTable object to the mainFrame JFrame object 

        mainFrame.add(mainTable);

        // Calling setDefaultCloseOperation and giving the
        // argument to JFrame.EXIT_ON_CLOSE to exit the application
        // on the default window close operation

        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Calling pack() method on mainFrame to cause the window
        // to be sized to the fit the preffered size and layouts 
        // of its subcomponents

        mainFrame.pack();

        // Calling setVisible() method on mainFrame and setting argument to 
        // true to show the GUI window

        mainFrame.setVisible(true);

        // Calling System.out.println() method to print out the data set table 
        // with the appropriate values and formatting and calling the Math class round() method
        // where necessary to round the double values listed (itAvgCount, reAvgCount, itCoefCount,
        // reCoefCount, itAvgTime, reAvgTime, itCoefCTime, reCoefTime)

        System.out.println("\nData Size: " + arraySize + "\n\tIterative Algorithm Results: \t\t\t\tRecursive Algorithm Results:" +
        "\n\tAverage Count: " + Math.round(itAvgCount) + "\t\t\t\t\tAverage Count: " + Math.round(reAvgCount) +
        "\n\tCoefficient Count: " + Math.round(itCoefCount) + "\t\t\t\tCoefficient Count: " + Math.round(reCoefCount) +
        "\n\tAverage Time: " + Math.round(itAvgTime) + "\t\t\t\t\tAverage Time: " + Math.round(reAvgTime) +
        "\n\tCoefficient Time: " + Math.round(itCoefTime) + "\t\t\t\tCoefficient Time: " + Math.round(reCoefTime) + "\n"); 

    }   // End of displayReport() method 

}   // End of Benchmark class 

