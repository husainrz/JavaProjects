// CMSC 451 7380 Design and Analysis of Computer Algorithms
// Week 4 - Project 1
// Husain Rizvi
// November 11, 2022

// This program essentially benchmarks the behavior of Java implementations of a 
// bubble sort sorting algorithm. It includes both an iterative and recursive version
// of the algorithm and produces a report based on randomly generated data sets. 

package Project1;   // Project1 package 

// This Report class contains the main method that generates the report and 
// creates the integer array for the sizes of the report 

// Creating public class Report

public class Report { // Start of class Report 

    // Creating main() method that throws an Exception to create an array of the sizes needed and then
    // to generate the report by creating a new Benchmark class object with the 
    // sizes integer array as the argument 

    public static void main(String[] args) throws Exception{    // Start of main() method 

        // Creating an integer array, sizes, that generates the data set that is going to 
        // be used for the sizes of the table 

		int[] sizes = {100, 200, 400, 800, 1000};
        
        // Initializing Benchmark() class and using the sizes integer array as the argument to generate the report 

        new Benchmark(sizes);   

    }   // End of main() method 
    
}   // End of class Report 
