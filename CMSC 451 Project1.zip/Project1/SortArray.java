// CMSC 451 7380 Design and Analysis of Computer Algorithms
// Week 4 - Project 1
// Husain Rizvi
// November 11, 2022

// This program essentially benchmarks the behavior of Java implementations of a 
// bubble sort sorting algorithm. It includes both an iterative and recursive version
// of the algorithm and produces a report based on randomly generated data sets. 

package Project1;   // Project1 package 

// This SortArray interface contains the method declarations for the integer array methods 
// iterativeSort and recursiveSort that are used in the BubbleSort.java class. 
// Both the iterativeSort and recursiveSort methods take an integer array as arguments
// and throw the newly created IncorrectSortError exception 

public interface SortArray {    // Start of SortArray interface 

    // Creating two method signatures for the SortArray interface to be implemented in the BubbleSort.java class

    public int getCount(); // Creating the method signature for the getCount() method that returns an integer value 
    public long getTime(); // Creating the method signature for the getTime() method that returns a long value 

    // Creating the method signature for the iterativeSort() method that takes
    // an integer array as an argument and throws the IncorrectSortError exception 

    public int[] iterativeSort(int[] array) throws IncorrectSortError;

    // Creating the method signature for the recursiveSort() method that takes
    // an integer array as an argument and throws the IncorrectSortError exception 

    public int[] recursiveSort(int[] array) throws IncorrectSortError;
    
}   // End of SortArray interface
