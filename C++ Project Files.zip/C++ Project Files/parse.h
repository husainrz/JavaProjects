// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

#include <iostream>

#include <string>

//declare a function parseName()

string parseName(stringstream &in);