// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

#include <strstream>

#include <vector>

using namespace std;

//define the class Variable subclass of the Operand

class Variable : public Operand{

    public:

    //define the construtor

    Variable(string name){

        this->name = name;

    }

    //define the function evaluate()

    int Variable::evaluate();

    private:

    string name;

};