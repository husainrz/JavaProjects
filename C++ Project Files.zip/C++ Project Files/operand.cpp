// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

#include <cctype>

#include <iostream>

#include <list>

#include <string>

using namespace std;

#include "expression.h"

#include "subexpression.h"

#include "operand.h"

#include "variable.h"

#include "literal.h"

#include "parse.h"

#include <sstream>

//definition of the function parse()

Expression* Operand::parse(stringstream& in){

    char paren;

    double value;

    in >> ws;

    if (isdigit(in.peek())){

        in >> value;

        Expression* literal = new Literal(value);

        return literal;

    }

    if (in.peek() == '('){

        in >> paren;

        return SubExpression::parse(in);

    } else

        return new Variable(parseName(in));

    return 0;

}