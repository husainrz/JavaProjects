// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

// define the class SubExpression

class SymbolTable{

    public:

    // constructor 

    SymbolTable(){}

    // declare the function

    void insert(string variable, int value);

    int lookUp(string variable) const;

    void init();

    private:

    // define the structure Symbol

    struct Symbol{
        
        Symbol(string variable, int value){
            this->variable = variable;
            this->value = value;   
        }

        string variable;

        int value;

    };

    // create a vector of type Symbol

    vector <Symbol> elements;

};
