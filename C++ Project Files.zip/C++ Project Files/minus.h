// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

//define the class Minus subclass of the SubExpression

class Minus : public SubExpression{

    public:

    //define the default construtor

    Minus(Expression* left, Expression* right) : SubExpression(left, right){}

    //define the function evaluate()

    int evaluate(){

        //subtract the value of right from the value of the left

        //and return the value.

        return left->evaluate() - right->evaluate();

    }

};