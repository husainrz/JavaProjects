// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

#include <cctype>

#include <iostream>

#include <string>

#include <sstream>

using namespace std;

#include "parse.h"

//definition of the function parseName()

string parseName(stringstream &in){

    char alnum;

    string name = "";

    in >> ws;

    while (isalnum(in.peek())){

        in >> alnum;

        name += alnum;

    }

    return name;

}