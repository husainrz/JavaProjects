// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

#include <string>
#include <vector>
using namespace std;

#include "symboltable.h"

// definition of the function insert()

void SymbolTable::insert(string variable, int value)
{
    // push the symbol in to the vector
    const Symbol& symbol = Symbol(variable, value);
    elements.push_back(symbol);
}

// definition of the function lookUp()

int SymbolTable::lookUp(string variable) const
{
    // search in the vector and return the value
    for (int i = 0; i < elements.size(); i++)
        if (elements[i].variable == variable)
             return elements[i].value;
    return -1;
}

void SymbolTable::init(){
    elements.clear();
}
