// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

// Using the #include directive to include header/standard files

#include <iostream> // Using #include directive to include the iostream header file
#include <string>  // Using #include directive to include the string header file
#include <vector>  // Using #include directive to include the vector header file
#include <fstream> // Using #include directive to include the fstream header file
#include <sstream> // Using #include directive to include the sstream header file

// The keyword using below is being used to specify that the program is
// using the standard namespace, std

using namespace std;    // Using the standard namespace 

// Using the #include directive to include user-defined files

#include "expression.h" // Using #include directive to include the expression user-defined file
#include "subexpression.h" // Using #include directive to include the subexpression user-defined file  
#include "symboltable.h"    // Using #include directive to include the symboltable user-defined file 
#include "parse.h"  // Using #include directive to include the parse user-defined file 

SymbolTable symbolTable;    // Creating an object of SymbolTable with the identifier as symbolTable 

// We begin with the main function and a subordinate function, parseAssignments().
// The main function reads in the program, calls upon the static function parse of the SubExpression class to parse it,
// and then builds an arithmetic expression tree. 

void parseAssignments(stringstream& in);    // Creating/declaring method signature for the void method, parseAssignments();

// Defining integer main() method that creates an input file stream

int main(){ // Start of main() method

    Expression* expression;
    char paren, comma;
    string line;

    // create an input file stream

    ifstream fin("input.txt");

    // check, if the file is not opened

    // then display a error message

    if(!fin.is_open())
    perror("error while opening file");

    // use a loop, to read the content from the file

    while(getline(fin, line)){

        symbolTable.init();

        if(!fin)
        break;
        
        stringstream in(line, ios_base::in);

        in >> paren;

        cout << line << " ";

        expression = SubExpression::parse(in);

        in >> comma;

        // call the function

        parseAssignments(in);

        // Display the result

        int result = expression->evaluate();

        cout << "Value = "<< result << endl;

    }

    system("pause");

    return 0;

}   // End of main() method 

// definition of the function parseAssignments()

void parseAssignments(stringstream& in){

    char assignop, delimiter;

    string variable;

    int value;

    symbolTable.init();

    do{
        variable = parseName(in);

        in >> ws >> assignop >> value >> delimiter;

        symbolTable.insert(variable, value);
    } while(delimiter == ',');

}
