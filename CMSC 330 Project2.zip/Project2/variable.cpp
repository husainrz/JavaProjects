// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

#include <strstream>

#include <vector>

using namespace std;

#include "expression.h"

#include "operand.h"

#include "variable.h"

#include "symboltable.h"

//create an object of SymbolTable

extern SymbolTable symbolTable;

//definition of the function evaluate()

int Variable::evaluate(){

    //return the name from the symbolTable

    return symbolTable.lookUp(name);

}