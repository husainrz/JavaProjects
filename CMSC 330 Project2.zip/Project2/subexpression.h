// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

//define the class SubExpression subclass of the Expression

class SubExpression : public Expression{

    public:

    //constructor

    SubExpression(Expression* left, Expression* right);

    //declare a static function parse()

    static Expression* parse(stringstream& in);

    protected:

    //declare the variables

    Expression* left;

    Expression* right;

};