// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

// As is customary in C++, the bodies of the member functions of that class are contained in this file, subexpression.cpp

#include <iostream>

using namespace std;

#include "expression.h"

#include "subexpression.h"

#include "operand.h"

#include "plus.h"

#include "minus.h"

#include "times.h"

#include "divide.h"

#include <sstream>

//define the constructor

SubExpression::SubExpression(Expression* left, Expression* right){

    this->left = left;

    this->right = right;

}

//definition of the class parse()

Expression* SubExpression::parse(stringstream& in){

    Expression* left;

    Expression* right;

    char operation, paren;

    //read the Operand

    left = Operand::parse(in);

    //read the operation

    in >> operation;

    //read the Operand

    right = Operand::parse(in);

    //read the paren

    in >> paren;

    switch (operation){

        case '+':

            return new Plus(left, right);

        case '-':

            return new Minus(left, right);

        case '*':

            return new Times(left, right);

        case '/':

            return new Divide(left, right);

    }

    system("pause");

    return 0;

}