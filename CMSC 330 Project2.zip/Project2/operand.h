// CMSC 330 7381 Advanced Programming Languages
// Week 8 - Project 2
// Husain Rizvi
// December 8, 2022

// This program involves completing and extending the C++ program that 
// evaluates statements of an expression language contained in the module 3 case study. 

//define the class Operand subclass of the Expression

class Operand : public Expression{

    public:

    //declare a static function parse()

    static Expression* parse(stringstream& in);

};